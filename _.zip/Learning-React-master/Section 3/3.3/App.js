import React, { Component } from 'react';

import AddressBook from './addressBook/AddressBook'

class App extends Component {
  render() {
    return (
      <div className="App">
        <AddressBook />
      </div>
    );
  }
}

export default App;
