import React from 'react'

const Home = () => {
    return (
        <h2>Home page</h2>
    )
}

export default Home