import React from 'react'

const Error = () => {
    return (
        <h2>Error! Try again.</h2>
    )
}

export default Error